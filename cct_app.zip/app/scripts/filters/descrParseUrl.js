'use strict';

angular.module('filters.descrParseUrl', [])
   .filter('descrParseUrl', function() {
	   	var urlPattern = /(http|ftp|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?/gi;
	   	var urlName;
	    var url;
	    
	    return function (text) {
	        url = text.match(urlPattern);
	        
	        if(url != null){
		        urlName=url.toString().split(".").splice(1,1);
		        // console.log(url.toString().split(".").splice(1,1));
		        // console.log(text.replace(urlPattern, "<a style='text-transform:capitalize;' target='_blank' href='" + url + "'>" + urlName + "</a>"));
		        return text.replace(urlPattern, "<a style='text-transform:capitalize;' target='_blank' href='" + url + "'>" + urlName + "</a>");
		    }

		    else {
		    	// console.log(text);
		    	return text;
		    }
	    };
   });