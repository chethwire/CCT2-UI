'use strict';

angular.module('security', [
    'security.service',
    'security.interceptor',
    'security.login',
    'security.authorization']);