'use strict';
angular.module('security.login', ['security.login.form', 'security.login.toolbar']);