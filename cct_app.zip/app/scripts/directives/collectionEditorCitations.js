'use strict';

angular.module('directives.collectionEditorCitations',[])
.directive('collectionEditorCitations', function(){
	// console.log("checking");
	
	return {
		restrict: "E",
		// require: "ngModel",
		scope:{
			// frmt: '=?',
			target: '=',
			citFrm:'=',
			collection:'=',
			getCit: '&'
		},

		template: '<input type="radio" name="artfmt" value="articleDefault" ng-model="artCitFrm" ng-checked="artChk" ng-change="shw()">'
					+ '<span style = "padding-left:10px;">Article Default<br>'
					+ '<span style = "padding-left:20px;">Title<br>'
					+ '<span style = "padding-left:20px;">Type<br>'
					+ '<span style = "padding-left:20px;">Date</span>'
				+ '<input style="position:relative;top:-58px;left:85px;" type="radio" name="frmt1" value="articleFormat1" ng-model="artCitFrm" ng-checked="artChk1" ng-change="shw()">'
					+ '<span style = "position:relative;top:-58px;left:85px;padding-left:10px;">Article Format-1 <br>'
					+ '<span style = "position:relative;left:75px;">Title<br>'
					+ '<span>Type<br>'
					+ '<span>Author<br>' 
					+ '<span>Date:<span style = "padding-left:10px;"> DOI:<br></span>'
				+ '<input style="position:relative;top:-95px;left:140px;bottom:-50px;" type = "radio" name="frmt2" value="articleFormat2" ng-model="artCitFrm" ng-checked="artChk2" ng-change="shw()">'
	                + '<span style="position:relative;top:-95px;left:140px;padding-left:10px;">Article Format-2<br>'
	                + '<span style = "padding-left:20px;">Title<br>'
	                + '<span style = "padding-left:20px;">Type<br>'
	                + '<span style = "padding-left:20px;">Author<br>'	                
	                + '<span style = "padding-left:20px;">Date<br></span>'
	            + '<input style="position:relative;top:-95px;left:165px" type="radio" name="bkfmt" value="bookDefault" ng-model="bkCitFrm" ng-checked="bkChk" ng-change="shw()">'
					+ '<span style = "position:relative;top:-95px;left:165px;padding-left:10px;">Book Default<br>'
					+ '<span style = "padding-left:20px;">Title<br>'
					+ '<span style = "padding-left:20px;">Type<br>'
					+ '<span style = "padding-left:20px;">Date</span>'
                + '<input style="position:relative;top:-58px;left:85px;bottom:-50px;" type="radio" name="frmt3" value="bookFormat1" ng-model="bkCitFrm" ng-checked="bkChk1" ng-change="shw()">'
					+ '<span style = "position:relative;top:-58px;left:85px;padding-left:10px;">Book Format-1 <br>'
					+ '<span style = "position:relative;left:75px;">Title<br>'
					+ '<span>Type<br>'					
					+ '<span>Author<br>' 
					+ '<span>Date:<span style = "padding-left:10px;">eISBN:<br></span>'
                + '<input style="position:relative;top:-98px;left:140px;bottom:-50px;" type = "radio" name="frmt4" value="bookFormat2" ng-model="bkCitFrm" ng-checked="bkChk2" ng-change="shw()">'
	                + '<span style="position:relative;top:-98px;left:140px;padding-left:10px;">Book Format-2<br>'
	                + '<span style = "padding-left:20px;">Title<br>'
	                + '<span style = "padding-left:20px;">Type<br>'	                
	                + '<span style = "padding-left:20px;">Author<br>'	                
	                + '<span style = "padding-left:20px;">Date<br></span>',	

	                      
       link: function($scope, element,$attrs){
	       	$scope.selCit;
	       	console.log($scope.collection);
	       	var node = element.find('input');

            node.bind('change', function(e) {//e is the event object           
                 // $scope.frmt = e.target.value;
                 $scope.selCit=e.target.value;
                 $scope.$apply();
                 //$rootScope.tr = $scope.frmt;
                // console.log($scope.frmt);
                $scope.shw=function(){
                	$scope.getCit({citations:$scope.selCit});
                	console.log($scope.artCitFrm);                	
                } 
            });	                 	
       },


       controller: function($scope){
		   	// $scope.currColl;
		   	$scope.$watch("collection",function(newVal,oldVal,scope){
		   		if(newVal.artCitationFmt === "default" || newVal.artCitationFmt === "articleDefault" ){
		   			$scope.artChk=true;
		   		}
		   		else if(newVal.artCitationFmt === "articleFormat1"){
		   			$scope.artChk1=true;
		   			// $scope.currColl=newVal;
		   			// console.log($scope.currColl.artCitationFmt);
		   			console.log(newVal.artCitationFmt);
		   		}
		   		else if(newVal.artCitationFmt === "articleFormat2"){
		   			$scope.artChk2=true;
		   		}

		   		if(newVal.bkCitationFmt === "default" || newVal.bkCitationFmt === "bookDefault"){
		   			$scope.bkChk=true;
		   		}
		   		else if(newVal.bkCitationFmt === "bookFormat1"){
		   			$scope.bkChk1=true;
		   		}
		   		else if (newVal.bkCitationFmt === "bookFormat2"){
		   			$scope.bkChk2=true;
		   		}
       }
       
   };
});